# -*- coding: utf-8 -*-
from odoo import http

# class AccountHierarchy(http.Controller):
#     @http.route('/account_hierarchy/account_hierarchy/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/account_hierarchy/account_hierarchy/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('account_hierarchy.listing', {
#             'root': '/account_hierarchy/account_hierarchy',
#             'objects': http.request.env['account_hierarchy.account_hierarchy'].search([]),
#         })

#     @http.route('/account_hierarchy/account_hierarchy/objects/<model("account_hierarchy.account_hierarchy"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('account_hierarchy.object', {
#             'object': obj
#         })