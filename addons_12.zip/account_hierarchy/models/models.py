# -*- coding: utf-8 -*-

import time
import math
import re

from odoo.osv import expression
from odoo.tools.float_utils import float_round as round
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
from odoo import api, fields, models, _

class AccountAccountType(models.Model):
    _inherit = "account.account.type"

    type = fields.Selection(selection_add=[('view', 'View')])


class AccountAccount(models.Model):
    _inherit = "account.account"
    _parent_name = "parent_id"
    #_parent_store = True
    _parent_order = 'parent_left'

    @api.multi
    @api.depends('parent_id', 'parent_id.level')
    def _get_level(self):
        for acc in self:
            level = 0
            if acc.parent_id:
                level = acc.parent_id.level + 1
            acc.level = level

    def _get_children(self):
        return self.search([('parent_id', 'child_of', self.ids)])

    @api.depends('name')
    def _compute(self):
        children = self._get_children()

        if children:
            account_result = {}

            tables, where_clause, where_params = self.env['account.move.line']._query_get()
            tables = tables.replace('"', '')
            if not tables:
                tables = 'account_move_line'
            wheres = [""]
            if where_clause.strip():
                wheres.append(where_clause.strip())
            filters = " AND ".join(wheres)

            request = (
                    "SELECT account_id AS id, "
                    "SUM(debit) AS debit, "
                    "SUM(credit) AS credit, "
                    "(SUM(debit) - SUM(credit)) AS balance"
                    " FROM " + tables +
                    " WHERE account_id IN %s " + filters +
                    " GROUP BY account_id"
            )
            params = (tuple(children.ids),) + tuple(where_params)
            self.env.cr.execute(request, params)
            for row in self.env.cr.dictfetchall():
                account_result[row.pop('id')] = row

        sums = {}
        for c in children.sorted(reverse=True):
            for fn in ['debit', 'credit', 'balance']:
                sums.setdefault(c.id, {})[fn] = account_result.get(c.id, {}).get(fn, 0.0)
                for child in c.child_id:
                    if child.id in sums:
                        sums[c.id][fn] += sums[child.id][fn]

        for account in self:
            if account.id in sums.keys():
                account.debit = sums[account.id].get('debit')
                account.credit = sums[account.id].get('credit')
                account.balance = sums[account.id].get('balance')

    parent_id = fields.Many2one('account.account', 'Parent Account', index=True, ondelete='cascade')
    child_id = fields.One2many('account.account', 'parent_id', 'Child Accounts')
    parent_left = fields.Integer('Left Parent', index=1)
    parent_right = fields.Integer('Right Parent', index=1)
    level = fields.Integer(compute='_get_level', string='Level', store=True)
    balance = fields.Monetary(string='Balance', compute=_compute)
    credit = fields.Monetary(string='Credit', compute=_compute)
    debit = fields.Monetary(string='Debit', compute=_compute)
