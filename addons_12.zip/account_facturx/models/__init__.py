# -*- encoding: utf-8 -*-

from . import account_invoice
from . import ir_actions_report
