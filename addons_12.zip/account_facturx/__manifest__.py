# -*- coding: utf-8 -*-
{
    'name' : 'Import Vendor Bills From XML',
    'version' : '1.0',
    'category': 'Accounting',
    'depends' : ['account'],
    'data': [
        'data/facturx_templates.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': True,
}
